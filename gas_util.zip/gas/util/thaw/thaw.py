# thaw.py
#
# NOTE: This file lives on the Utils instance
#
# Copyright (C) 2011-2019 Vas Vasiliadis
# University of Chicago
##
__author__ = 'Vas Vasiliadis <vas@uchicago.edu>'

import os
import sys

# Import utility helpers
sys.path.insert(1, os.path.realpath(os.path.pardir))
import helpers
import os
import boto3
import botocore
from botocore.exceptions import ClientError
import json

# Get configuration
from configparser import SafeConfigParser

# Add utility code here
if __name__ == "__main__":
    # Get configuration
    config = SafeConfigParser(os.environ)
    config.read('thaw_config.ini')
    try:
        # connect to sqs resource and idenity the message que
        sqs = boto3.resource('sqs', region_name=config['aws']['AwsRegionName'])
        que = sqs.get_queue_by_name(QueueName=config['aws']['AwsQueueName'])
        # connect to s3 client
        s3_client = boto3.client('s3', region_name=config['aws']['AwsRegionName'])
        # connect to galcier resource and client
        glacier = boto3.resource('glacier', region_name=config['aws']['AwsRegionName'])
        glacier_client = boto3.client('glacier', region_name=config['aws']['AwsRegionName'])
    except ClientError as e:
        # report error
        print(e)
        print('Client error. Fail to get queue.')
    except botocore.exceptions.ConnectionTimeourError as e:
        print(e)
        print('Connetion timeout.')
    except botocore.exceptions.IncompleteReadError as e:
        print(e)
        print('Incomplete read.')
    except:
        print('Undefined error. Fail to get que from server.')

        # Poll the message queue in a loop 
    while True:  
        try:
            # Boto 3 Docs 1.13.3 documentation. [Source Code]
            # https://boto3.amazonaws.com/v1/documentation/api/latest/guide/sqs.html
            # receive messages from SQS using long poll
            messages = que.receive_messages(WaitTimeSeconds=int(config['aws']['WaitTimeSeconds']), 
                                        MessageAttributeNames=['string',],
                                        MaxNumberOfMessages=1)
        except ClientError as e:
            # report error
            print(e)
            print('Fail to receive messages.')
        except botocore.exceptions.ConnectionTimeourError as e:
            print(e)
            print('Connetion timeout.')
        except botocore.exceptions.IncompleteReadError as e:
            print(e)
            print('Incomplete read.')
        except:
            print('Fail to receive messages from queue.')
        # iterate through all messages pulled
        for message in messages:
            # parse the data
            data = json.loads(message.body)
            data = json.loads(data['Message'])
            print(data)
            # extract parameters from json data
            archive_id = data['ArchiveId']
            job_id = data['JobId']
            desc = data['JobDescription']
            file_name = desc.split('~~~')[0]
            user_id = desc.split('~~~')[1]
            try:
                # Glacier. Boto 3 Docs 1.13.14 documentation. [Source Code]
                # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/glacier.html
                # get the glacier job using job id
                job = glacier.Job('-',config['aws']['VaultName'],job_id)
                # get job output
                response = job.get_output()
            except ClientError as e:
                # report error
                print(e)
                print('Client error. Fail to get glaicer job.')
            except botocore.exceptions.ConnectionTimeourError as e:
                print(e)
                print('Connetion timeout.')
            except botocore.exceptions.IncompleteReadError as e:
                print(e)
                print('Incomplete read.')
            except:
                print('Fail to get glaicer job.')
            # Glacier. Boto 3 Docs 1.13.14 documentation. [Source Code]
            # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/glacier.html
            # get the glacier job using job id
            # read the file content from glacier
            body = response['body']
            data = body.read()
            # write the content to file
            f = open(file_name, "a")
            f.write(data.decode())
            f.close()

            try:
                # delete the archive from glacier
                response = glacier_client.delete_archive(
                    vaultName=config['aws']['VaultName'],
                    archiveId=archive_id
                )
            except ClientError as e:
                print('Fail to delete archive from glacier.')
                print(e)

            try:
                # prepare s3 object key
                object_key = config['aws']['AwsS3KeyPrefix'] + user_id + '/' + file_name
                # upload results file to s3 bucket
                response = s3_client.upload_file(file_name, config['aws']['AwsS3ResultsBucket'], object_key)
            except ClientError as e:
                print('Fail to upload results file.')
                print(e)

            try:
                # delete the message
                message.delete()
            except ClientError as e:
                # report error
                print(e)
                print('Fail to receive messages.')
            except botocore.exceptions.ConnectionTimeourError as e:
                print(e)
                print('Connetion timeout.')
            except botocore.exceptions.IncompleteReadError as e:
                print(e)
                print('Incomplete read.')
            except:
                print('Fail to delete message from que.')
            # remove the local file
            os.remove(file_name)


### EOF