# archive.py
#
# NOTE: This file lives on the Utils instance
#
# Copyright (C) 2011-2019 Vas Vasiliadis
# University of Chicago
##
__author__ = 'Vas Vasiliadis <vas@uchicago.edu>'

import os
import sys

# Import utility helpers
sys.path.insert(1, os.path.realpath(os.path.pardir))
import helpers
import os
import boto3
import botocore
from botocore.exceptions import ClientError
import json

# Get configuration
from configparser import SafeConfigParser


# Add utility code here
if __name__ == "__main__":
    # Get configuration
    config = SafeConfigParser(os.environ)
    config.read('archive_config.ini')
    try:
        # connect to sqs resource and idenity the message que
        sqs = boto3.resource('sqs', region_name=config['aws']['AwsRegionName'])
        que = sqs.get_queue_by_name(QueueName=config['aws']['AwsQueueName'])
        # connect to s3 resource
        s3 = boto3.resource('s3', region_name=config['aws']['AwsRegionName'])
        # connect to dynamodb databse resource
        dynamodb = boto3.resource('dynamodb', region_name=config['aws']['AwsRegionName'])
        # connect to galcier client
        glacier = boto3.client('glacier', region_name=config['aws']['AwsRegionName'])
    except ClientError as e:
        # report error
        print(e)
        print('Client error.')
    except botocore.exceptions.ConnectionTimeourError as e:
        print(e)
        print('Connetion timeout.')
    except botocore.exceptions.IncompleteReadError as e:
        print(e)
        print('Incomplete read.')
    except:
        print('Undefined error.')

    # Poll the message queue in a loop 
    while True:  
        try:
            # Boto 3 Docs 1.13.3 documentation. [Source Code]
            # https://boto3.amazonaws.com/v1/documentation/api/latest/guide/sqs.html
            # receive messages from SQS using long poll
            messages = que.receive_messages(WaitTimeSeconds=int(config['aws']['WaitTimeSeconds']), 
                                        MessageAttributeNames=['string',],
                                        MaxNumberOfMessages=1)
        except ClientError as e:
            # report error
            print(e)
            print('Fail to receive messages.')
        except botocore.exceptions.ConnectionTimeourError as e:
            print(e)
            print('Connetion timeout.')
        except botocore.exceptions.IncompleteReadError as e:
            print(e)
            print('Incomplete read.')
        except:
            print('Fail to receive messages from queue.')
        # iterate through all the messages 
        for message in messages:
            # parse the pulled message
            data = json.loads(message.body)
            data = json.loads(data['Message'])
            print(data)
            # extract parameters from json data
            job_id = data['job_id']
            user_id = data['user_id']
            result_file_name = data['result_file_name']
            # get user profile
            profile = helpers.get_user_profile(id=user_id, db_name=config['gas']['AccountsDatabase'])
            # check the role of user
            if profile['role'] == "premium_user":
                # do not need to archive the message if the user is premuim
                print('premium_user')
                try:
                    # delete the message
                    message.delete()
                except ClientError as e:
                    # report error
                    print(e)
                    print('Fail to delete the message.')
                except botocore.exceptions.ConnectionTimeourError as e:
                    print(e)
                    print('Connetion timeout.')
                except botocore.exceptions.IncompleteReadError as e:
                    print(e)
                    print('Incomplete read.')
                except:
                    print('Fail to delete message from que.')
                continue

            try:
                # prepare the s3 object key
                object_key = config['aws']['AwsS3KeyPrefix'] + user_id + "/" + result_file_name
                # download the s3 file
                s3.Bucket(config['aws']['AwsS3ResultsBucket']).download_file(object_key, result_file_name)
                # S3. Boto 3 Docs 1.13.14 documentation. [Source Code]
                # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/s3.html
                # remove the object from s3
                s3_obj = s3.Object(config['aws']['AwsS3ResultsBucket'],object_key)
                s3_obj.delete()
            except botocore.exceptions.ClientError as e:
                if e.response['Error']['Code'] == "404":
                    print("The object does not exist.")
                else:
                    raise
            # open the file and read the content
            f = open(result_file_name, "r")
            data = f.read().encode()
            # Glacier. Boto 3 Docs 1.13.14 documentation. [Source Code]
            # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/glacier.html
            # upload the file content to glacier
            try:
                response = glacier.upload_archive(
                    vaultName=config['aws']['GlacierVaultName'],
                    archiveDescription=result_file_name,
                    body=data
                )
                # get the archive id
                archiveId = response['archiveId']
                print(archiveId)
            except ClientError as e:
                # report error
                print(e)
                print('Fail to upload to Glacier.')
            except botocore.exceptions.ConnectionTimeourError as e:
                print(e)
                print('Connetion timeout.')
            except botocore.exceptions.IncompleteReadError as e:
                print(e)
                print('Incomplete read.')
            except:
                print('Fail to delete message from que.')
            continue

            try:
                # identify the table
                ann_table = dynamodb.Table(config['aws']['AwsDynamodbAnnotationsTable'])
                # update the archive id for item
                ann_table.update_item(
                        Key={
                        'job_id': job_id
                        },
                        UpdateExpression="set results_file_archive_id = :r1",
                        ExpressionAttributeValues={
                        ':r1': archiveId,
                        }) 
            except ClientError as e:
                print('Fail to update the data in table!')
                print(e)
            # remove the downloaded file from local machine
            os.remove(result_file_name)
            try:
                # delete the message
                message.delete()
            except ClientError as e:
                # report error
                print(e)
                print('Fail to delete the message.')
            except botocore.exceptions.ConnectionTimeourError as e:
                print(e)
                print('Connetion timeout.')
            except botocore.exceptions.IncompleteReadError as e:
                print(e)
                print('Incomplete read.')
            except:
                print('Fail to delete message from que.')


            








### EOF