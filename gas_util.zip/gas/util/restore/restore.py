# restore.py
#
# NOTE: This file lives on the Utils instance
#
# Copyright (C) 2011-2019 Vas Vasiliadis
# University of Chicago
##
__author__ = 'Vas Vasiliadis <vas@uchicago.edu>'

import os
import sys

# Import utility helpers
sys.path.insert(1, os.path.realpath(os.path.pardir))
import helpers
import os
import boto3
import botocore
from botocore.exceptions import ClientError
import json
from boto3.dynamodb.conditions import Key

# Get configuration
from configparser import SafeConfigParser


# Add utility code here
if __name__ == "__main__":
    # Get configuration
    config = SafeConfigParser(os.environ)
    config.read('restore_config.ini')
    try:
        # connect to sqs resource and idenity the message que
        sqs = boto3.resource('sqs', region_name=config['aws']['AwsRegionName'])
        que = sqs.get_queue_by_name(QueueName=config['aws']['AwsQueueName'])
        # connect to s3 resource
        s3 = boto3.resource('s3', region_name=config['aws']['AwsRegionName'])
        # connect to dynamodb databse resource
        dynamodb = boto3.resource('dynamodb', region_name=config['aws']['AwsRegionName'])
        # connect to galcier client
        glacier = boto3.client('glacier', region_name=config['aws']['AwsRegionName'])
    except ClientError as e:
        # report error
        print(e)
        print('Client error.')
    except botocore.exceptions.ConnectionTimeourError as e:
        print(e)
        print('Connetion timeout.')
    except botocore.exceptions.IncompleteReadError as e:
        print(e)
        print('Incomplete read.')
    except:
        print('Undefined error.')

    # Poll the message queue in a loop 
    while True:  
        
        try:
            # Boto 3 Docs 1.13.3 documentation. [Source Code]
            # https://boto3.amazonaws.com/v1/documentation/api/latest/guide/sqs.html
            # receive messages from SQS using long poll
            messages = que.receive_messages(WaitTimeSeconds=int(config['aws']['WaitTimeSeconds']), 
                                        MessageAttributeNames=['string',],
                                        MaxNumberOfMessages=1)
        except ClientError as e:
            # report error
            print(e)
            print('Fail to receive messages.')
        except botocore.exceptions.ConnectionTimeourError as e:
            print(e)
            print('Connetion timeout.')
        except botocore.exceptions.IncompleteReadError as e:
            print(e)
            print('Incomplete read.')
        except:
            print('Fail to receive messages from queue.')
        
        # iterate through all the messages 
        for message in messages:
            # parse data from message
            data = json.loads(message.body)
            data = json.loads(data['Message'])
            print(data)
            # extract parameters from json data
            user_id = data['user_id']
            table = dynamodb.Table(config['aws']['AwsDynamodbAnnotationsTable'])
            try:
                # get all job tasks
                response = table.query(
                    IndexName = 'user_id_index',
                    KeyConditionExpression=Key('user_id').eq(user_id)
                    )
            except ClientError as e:
                # report error
                print(e)
                print('Fail to query database.')
            except botocore.exceptions.ConnectionTimeourError as e:
                print(e)
                print('Connetion timeout.')
            except botocore.exceptions.IncompleteReadError as e:
                print(e)
                print('Incomplete read.')
            except:
                print('Fail to receive messages from queue.')

            for item in response['Items']:
                # if the job has archive id
                if 'results_file_archive_id' in item:
                    # get archive id and file name
                    archive_id = item['results_file_archive_id']
                    file_name = item['s3_key_result_file']
                    try:
                        # Glacier. Boto 3 Docs 1.13.14 documentation. [Source Code]
                        # https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/glacier.html
                        # upload the file content to glacier
                        # intiate the glacier retrieve job
                        # try expedited
                        response = glacier.initiate_job(
                            vaultName=config['aws']['VaultName'],
                            jobParameters={
                                'ArchiveId': archive_id,
                                'Description': file_name+"~~~"+user_id,
                                'Type': 'archive-retrieval',
                                'SNSTopic': config['aws']['SNSThawTopic'],
                                'Tier': 'Expedited'
                            },  
                        )
                    except:
                        # otherwise, try standard retireve
                        response = glacier.initiate_job(
                            vaultName=config['aws']['VaultName'],
                            jobParameters={
                                'ArchiveId': archive_id,
                                'Description': file_name+"~~~"+user_id,
                                'Type': 'archive-retrieval',
                                'SNSTopic': config['aws']['SNSThawTopic'],
                                'Tier': 'Standard'
                            },  
                        )
                    print("jobId:" + response['jobId'])
            try:
                # delete the message
                message.delete()
            except ClientError as e:
                # report error
                print(e)
                print('Fail to receive messages.')
            except botocore.exceptions.ConnectionTimeourError as e:
                print(e)
                print('Connetion timeout.')
            except botocore.exceptions.IncompleteReadError as e:
                print(e)
                print('Incomplete read.')
            except:
                print('Fail to delete message from que.')
### EOF