#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 16:29:29 2020

@author: yueyangzhang
"""

__author__ = 'Vas Vasiliadis <vas@uchicago.edu>'

import sys
import time
import driver
import boto3
import os
from botocore.exceptions import ClientError


"""A rudimentary timer for coarse-grained profiling
"""
class Timer(object):
    def __init__(self, verbose=True):
        self.verbose = verbose

    def __enter__(self):
        self.start = time.time()
        return self

    def __exit__(self, *args):
        self.end = time.time()
        self.secs = self.end - self.start
        if self.verbose:
            print(f"Approximate runtime: {self.secs:.2f} seconds")

if __name__ == '__main__':
    # Get configuration
    config = SafeConfigParser(os.environ)
    config.read('ann_config.ini')
	# Call the AnnTools pipeline
    if len(sys.argv) > 1:
        with Timer():
            driver.run(sys.argv[1], 'vcf')
            # Upload the results file
            filePath = sys.argv[1]
            # extract path and file name
            data = filePath.split('/') 
            path = ''
            for i in range(len(data)-1):
                path += data[i] + '/'
            fullFileName = data[-1]
            fileName = fullFileName.split('.vcf')[0]
            # get the current path
            cwd = os.getcwd()
            # connect with s3
            s3_client = boto3.client('s3')
            # path of the complete file
            completeFileName = fileName + ".annot.vcf"
            completeFile = os.path.join(cwd, path, completeFileName)
            user_id = session['primary_identity']
            try:
                # upload results file to s3 bucket
                response = s3_client.upload_file(completeFile, config['aws']['AwsS3ResultsBucket'], config['aws']['AwsS3KeyPrefix'] + user_id + '/' + completeFileName)
            except ClientError as e:
                print('Fail to upload results file!')
                print(e)
            
            # Upload the log file
            logFileName = fileName + ".vcf.count.log" 
            logFile = os.path.join(cwd, path, logFileName)
            try:
                # upload log file to s3 bucket
                response = s3_client.upload_file(logFile, config['aws']['AwsS3ResultsBucket'], config['aws']['AwsS3KeyPrefix'] + user_id + '/' + logFileName)
            except ClientError as e:
                print('Fail to upload log file!')
                print(e)
            
            # Clean up (delete) local job files
            try:
                # remove the folder result file
                os.remove(completeFile)
                # remove log file
                os.remove(logFile)
                rawFilePath = os.path.join(cwd,filePath)
                # remove raw file
                os.remove(rawFilePath)
                # remove the empty folder
                folderPath = os.path.join(cwd,path)
                os.rmdir(folderPath)
                
            except FileNotFoundError as e:
                print("Fail to find the directory")
                print(e)
            except:
                print('Fail to remove local data.')
            # extract job id (UUID) from the inputs
            UUID = sys.argv[2]
            try:
                # Step 3: Create, Read, Update, and Delete an Item with Python. 
                # AWS Documentation. [Source Code]
                # https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/GettingStarted.Python.03.html
                # connect with database
                dynamodb = boto3.resource('dynamodb', region_name=config['aws']['AwsRegionName'])
                # identify the table
                ann_table = dynamodb.Table(config['aws']['AwsDynamodbAnnotationsTable'])
                # update the data for item
                ann_table.update_item(
                        Key={
                        'job_id': UUID
                        },
                        UpdateExpression="set s3_results_bucket = :r1, \
                                              s3_key_result_file = :r2, \
                                              s3_key_log_file = :r3, \
                                              complete_time = :r4, \
                                              job_status = :r5",
                        ExpressionAttributeValues={
                        ':r1': config['aws']['AwsS3ResultsBucket'],
                        ':r2': completeFileName,
                        ':r3': logFileName,
                        ':r4': int(time.time()),
                        ':r5': "COMPLETED"
                        }) 
            except ClientError as e:
                print('Fail to update the data in table!')
                print(e)

            user_id = session.get('primary_identity')
            profile = get_profile(identity_id=session.get('primary_identity'))

            data = {"job_id": UUID,
            "user_id": user_id, 
            "user_email": profile.email,
            "user_name": profile.name
            }
            # JSON encoding error publishing sns message with boto3. Stack Overflow. [Source Code]
            # https://stackoverflow.com/questions/35071549/json-encoding-error-publishing-sns-message-with-boto3
            # connect to SNS server
            try:
                sns = boto3.client('sns')
                # Publish a simple message to the specified SNS topic
                response = sns.publish(
                    TopicArn='arn:aws:sns:us-east-1:127134666975:zhan2212_job_results',   
                    Message = json.dumps(data) 
                )
            except ClientError as e:
                print(e)
                
    else:
        print("A valid .vcf file must be provided as input to this program.")

### EOF
