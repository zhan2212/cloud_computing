*** Modified for Spring 2020 Quarter ***

This directory contains the Flask-based web app for the GAS.

You will add code to `views.py` and add/update Jinja2 templates in `/templates`.